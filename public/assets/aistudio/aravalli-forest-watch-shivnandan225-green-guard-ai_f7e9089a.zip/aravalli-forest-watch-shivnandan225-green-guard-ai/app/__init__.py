"""GreenGuard AI application package."""
